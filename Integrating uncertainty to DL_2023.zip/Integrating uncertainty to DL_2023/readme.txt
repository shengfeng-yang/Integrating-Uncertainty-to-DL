1. Run atomsk.md to build the atomic model
2. Run tension.in using LAMMPS
3. Run ten_stress_strain.py to get the stress-strain curve from MD simulation.
4. Train the ML models (CNN, FNN, CNN-Prob, FNN-Prob)